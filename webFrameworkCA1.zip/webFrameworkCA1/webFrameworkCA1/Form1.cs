using webFrameworkCA1.obj;

namespace webFrameworkCA1
{
    public partial class createRace : Form
    {
        public createRace()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string eventName = txtEventName.Text;
            string eventLocation = txtEventLocation.Text;
            int eventNumberOfRaces;

            if (!int.TryParse(txtNumberOfRaces.Text, out eventNumberOfRaces))
            {
                MessageBox.Show("Invalid number of races. Please enter a valid number.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            raceEvent raceEventBox = new raceEvent
            {
                name = eventName,
                location = eventLocation,
                numOfRaces = eventNumberOfRaces
            };


            MessageBox.Show($"Race Event Created:\nName: {raceEventBox.name}\nLocation: {raceEventBox.location}\nNumber of Races: {raceEventBox.numOfRaces}", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

            

         


        }

        private void CreateRace(string eventName, string eventLocation, int eventNumberOfRaces)
        {
            raceEvent newEvent = new raceEvent(eventName, eventLocation, eventNumberOfRaces);
            
            
        }

        

        
    }
}