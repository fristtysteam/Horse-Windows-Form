﻿namespace webFrameworkCA1
{
    partial class createRace
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(createRace));
            label1 = new Label();
            pictureBox1 = new PictureBox();
            addHorseBtn = new Button();
            txtEventName = new TextBox();
            txtEventLocation = new TextBox();
            txtNumberOfRaces = new TextBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = SystemColors.InactiveBorder;
            label1.Font = new Font("Segoe UI Black", 35F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(410, 29);
            label1.Margin = new Padding(6, 0, 6, 0);
            label1.Name = "label1";
            label1.Padding = new Padding(5);
            label1.Size = new Size(586, 72);
            label1.TabIndex = 0;
            label1.Text = "MARCO HORSE RACING";
            label1.TextAlign = ContentAlignment.TopCenter;
            label1.Click += label1_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(1088, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(376, 670);
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // addHorseBtn
            // 
            addHorseBtn.Location = new Point(72, 133);
            addHorseBtn.Name = "addHorseBtn";
            addHorseBtn.Size = new Size(198, 40);
            addHorseBtn.TabIndex = 2;
            addHorseBtn.Text = "Add Race";
            addHorseBtn.UseVisualStyleBackColor = true;
            addHorseBtn.Click += button1_Click;
            // 
            // txtEventName
            // 
            txtEventName.Location = new Point(72, 221);
            txtEventName.Name = "txtEventName";
            txtEventName.Size = new Size(306, 35);
            txtEventName.TabIndex = 3;
            txtEventName.TextChanged += txtEventName_TextChanged;
            // 
            // txtEventLocation
            // 
            txtEventLocation.Location = new Point(72, 283);
            txtEventLocation.Name = "txtEventLocation";
            txtEventLocation.Size = new Size(306, 35);
            txtEventLocation.TabIndex = 3;
            txtEventLocation.TextChanged += txtEventLocation_TextChanged;
            // 
            // txtNumberOfRaces
            // 
            txtNumberOfRaces.Location = new Point(72, 344);
            txtNumberOfRaces.Name = "txtNumberOfRaces";
            txtNumberOfRaces.Size = new Size(306, 35);
            txtNumberOfRaces.TabIndex = 3;
            txtNumberOfRaces.TextChanged += txtNumberOfRaces_TextChanged;
            // 
            // createRace
            // 
            AutoScaleDimensions = new SizeF(13F, 28F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.InactiveBorder;
            ClientSize = new Size(1462, 668);
            Controls.Add(txtNumberOfRaces);
            Controls.Add(txtEventLocation);
            Controls.Add(txtEventName);
            Controls.Add(addHorseBtn);
            Controls.Add(pictureBox1);
            Controls.Add(label1);
            Cursor = Cursors.SizeNWSE;
            Font = new Font("Segoe UI Black", 15F, FontStyle.Bold, GraphicsUnit.Point);
            Margin = new Padding(6, 5, 6, 5);
            Name = "createRace";
            Text = "RaceCreator";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        private void txtEventName_TextChanged(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void txtEventLocation_TextChanged(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void txtNumberOfRaces_TextChanged(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion

        private Label label1;
        private PictureBox pictureBox1;
        private Button addHorseBtn;
        private TextBox txtEventName;
        private TextBox txtEventLocation;
        private TextBox txtNumberOfRaces;
    }
}